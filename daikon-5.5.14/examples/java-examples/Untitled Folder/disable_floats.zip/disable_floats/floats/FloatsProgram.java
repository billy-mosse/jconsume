package floats;

public class FloatsProgram
{
	public static double t;

	public static void main(String[] args)
	{
		t = 2.0;
	}
}